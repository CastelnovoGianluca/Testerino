<head>

  <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    </head>
<?php
include('DB_Helper.php');
$conn=connetti();

$nome;
if (isset($_GET['nome']))
{
    $nome = $_GET['nome'];
}
$query = "SELECT * FROM pokemon WHERE identifier LIKE '%".$nome."%' ";
$sth = $conn->prepare($query);
$sth->execute();
$ciao=$sth->fetch(PDO::FETCH_ASSOC);
echo "<table class='table table-dark'>";
echo "<tr><td>"."NOME". "</td><td>" . "ALTEZZA"."</td><td>" . "PESO" . "</td></tr>";
echo "<tr><td>"."<img src='main-sprites/".$ciao['id'].".png'>".$ciao['identifier']. "</td><td>"  . $ciao['height'] ."</td><td>"  .$ciao['weight'] . "</td></tr>";
echo "</table>";
?>
