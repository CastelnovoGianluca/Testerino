
<head>

  <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">


</head>
<body>
  <ul>
    <li><a class="active" href="index.php">Home</a></li>
  <adestra>  <li><a href="register.php" >Register</a></li> </adestra>
    <adestra> <li><a href="login.php">Login</a></li> </adestra>
    <li><a href="listapokemon.php">Ricerca</a></li>
    <li><a href="ricercapoke.php">Catalogo</a></li>
  </ul>
</ul>
<form name="ricerca" method="get" action="ricercapoke1.php">
  <table border="0" width="500" align="center" class="demo-table">
    <tr>
      <td>NOME POKEMON</td>
      <td><input type="text" class="demoInputBox" name="nome"</td>
      <input type="submit" name="ricerca" value="Ricerca" class="Ricerca"></td>
    </tr>
  </table>
</form>
</body>
<style>
adestra {
  float:right ;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #ffffff;
    text-decoration: none;
}

li {
    float: left;
}

li a {
    display: block;
    color: black;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover:not(.active) {
    background-color: #ff4f28;
}

.active {
    background-color: #ff2e00;
}
}
</style>
<?php
include('DB_Helper.php');

$conn=connetti();

$sql = "SELECT * FROM pokemon limit 700";
$sth = $conn->prepare($sql);
$sth->execute();

$result = $sth->fetch(PDO::FETCH_ASSOC);

echo "<table class='table table-dark'>";
echo "<tr><td>"."NOME". "</td><td>" . "ALTEZZA"."</td><td>" . "PESO" . "</td></tr>";

  while($result = $sth->fetch(PDO::FETCH_ASSOC))
  {
     echo "<tr><td>"."<img src='main-sprites/".$result['id'].".png'>".$result['identifier']. "</td><td>" . $result['height'] ."</td><td>" .$result['weight'] . "</td></tr>";
  }

echo "</table>";

?>
