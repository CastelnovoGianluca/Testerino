<head>

  <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<body>
  <ul>
    <li><a class="active" href="index.php">Home</a></li>
  <adestra>  <li><a href="register.php" >Register</a></li> </adestra>
    <adestra> <li><a href="login.php">Login</a></li> </adestra>
    <li><a href="listapokemon.php">Ricerca</a></li>
    <li><a href="ricercapoke.php">Catalogo</a></li>
</ul>
</head>
</body>
<style>
adestra {
  float:right ;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #ffffff;
    text-decoration: none;
}

li {
    float: left;
      text-decoration: none;
}

li a {
    display: block;
    color: black;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover:not(.active) {
    background-color: #ff4f28;
      text-decoration: none;
}

.active {
    background-color: #ff2e00;
      text-decoration: none;
}
</style>

<?php
include('DB_Helper.php');
$conn=connetti();
//$nome = $_GET['nome'];



      $x_pag = 10;

      if (isset($_GET['pag']))
      {
          $pag = $_GET['pag'];
      }
      else
      {
         $pag  = 1;
      }



      if (!$pag || !is_numeric($pag))
      {
          $pag = 1;
      }

      $sql = "SELECT count(*) FROM pokemon";
      $sth = $conn->prepare($sql);
      $sth->execute();
      $all_rows = $sth->fetchColumn();
      $all_pages = ceil($all_rows / $x_pag);
      $first = ($pag-1) * $x_pag;
      $sql = "SELECT * FROM pokemon LIMIT $first, $x_pag";
      $sth = $conn->prepare($sql);
      $sth->execute();

      echo "<table class='table table-dark'>";
      echo "<tr><td>"."NOME". "</td><td>" . "ALTEZZA"."</td><td>" . "PESO" . "</td></tr>";
      while($result = $sth->fetch(PDO::FETCH_ASSOC))
      {

      echo "<tr><td>"."<img src='main-sprites/".$result['id'].".png'>".$result['identifier']. "</td><td>" . $result['height'] ."</td><td>" .$result['weight'] . "</td></tr>";
      }
      echo "</table>";


      if ($all_pages > 1){
          if ($pag > 1){

              echo "<a href=\"" . $_SERVER['PHP_SELF'] . "?pag=" . ($pag - 1) . "\">";
              echo "PREVIOUSE PAGE</a>&nbsp;";
          }

          if ($all_pages > $pag){
              echo "<a href=\"" . $_SERVER['PHP_SELF'] . "?pag=" . ($pag + 1) . "\">";
              echo "NEXT PAGE</a>";
          }
          echo "<br>";

      }
  ?>
