<HTML><HEAD>

<?php
echo '<link href="tabelle.css" rel="stylesheet" type="text/css" />';
?>
</HEAD><BODY>
<?php
$db = mysql_connect("localhost" , "root" , "")
or die ("Non riesco a creare la connessione");
mysql_select_db("utenti") or die ("Non trovo il DB");
$sql = "SELECT ID_utente, nome_utente,password,conta_pres FROM users WHERE conta_pres <> 0";
$ris = mysql_query($sql) or die ("Query fallita");
echo "<TABLE><TR><TH>ID utente<TH>Nome utente<TH>Password<TH>Contatore visite</TR>";
$alt=true;
while($riga = mysql_fetch_array($ris))
{
 echo("<TR>");
 $altClass = $alt ? = CLASS='alt'" : "";
 echo "<TD".$altClass.">".$riga["ID_utente"];
 echo "<TD".$altClass.">".$riga["nome_utente"];
 echo "<TD".$altClass.">".$riga["password"];
 echo "<TD".$altClass.">".$riga["conta_pres"];
 $alt=!$alt;
}
mysql_close();
?>
</BODY></HTML>
