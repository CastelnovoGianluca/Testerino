DROP DATABASE;
CREATE DATABASE users;
USE users;

CREATE TABLE users (
ID_utente int(4) PRIMARY KEY,
nome_utente VARCHAR(20) NOT NULL,
password VARCHAR(20) NOT NULL,
conta_pres int(4) NOT NULL
);
INSERT INTO users VALUES

(1, "Rossi" , "Mario" , 100),
(2, "Bianchi" , "Giuseppe" , 300),
(3, "Verdi" , "Giovanni" , 450),
(4, "Bianchi" , "Giacomo" , 120),
(5, "Rossi" , "Antonio" , 250);
