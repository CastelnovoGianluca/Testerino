<HTML>

<HEAD>
</HEAD>
<BODY>
  <ul>
    <li><a class="active" href="index.php">Home</a></li>
  <adestra>  <li><a href="register.php" >Register</a></li> </adestra>
    <adestra> <li><a href="login.php">Login</a></li> </adestra>
    <li><a href="listapokemon.php">Ricerca</a></li>
    <li><a href="ricercapoke.php">Catalogo</a></li>
  </ul>
  <tr>
        <b><td>REGISTER</td></b>
        </tr>
  <form name="frmRegistration" method="post" action="register1.php">
  	<table border="0" width="500" align="center" class="demo-table">
  		<?php if(!empty($success_message)) { ?>
  		<div class="success-message"><?php if(isset($success_message)) echo $success_message; ?></div>
  		<?php } ?>
  		<?php if(!empty($error_message)) { ?>
  		<div class="error-message"><?php if(isset($error_message)) echo $error_message; ?></div>
  		<?php } ?>

  		<tr>
  			<td>USERNAME</td>
  			<td><input type="text" class="demoInputBox" name="userName"</td>
  		</tr>
  		<tr>
  			<td>NOME</td>
  			<td><input type="text" class="demoInputBox" name="firstName"</td>
  		</tr>
  		<tr>
  			<td>COGNOME</td>
  			<td><input type="text" class="demoInputBox" name="lastName" ></td>
  		</tr>
  		<tr>
  			<td>PASSWORD</td>
  			<td><input type="password" class="demoInputBox" name="password"></td>
  		</tr>
  		<tr>
  			<td>CONFERMA PASSWORD</td>
  			<td><input type="password" class="demoInputBox" name="confirm_password"></td>
  		</tr>
  		<tr>
  			<td>EMAIL</td>
  			<td><input type="text" class="demoInputBox" name="userEmail"</td>
  		</tr>
  		<tr>
  			<td colspan=2>
    			<input type="submit" name="register-user" value="REGISTER" class="btnRegister"></td>
  		</tr>
  	</table>
  </form>
  <style>
  adestra {
    float:right ;
  }
  @font-face {
    font-family: 'fonte2';
    src: url('C:\Program Files (x86)\Ampps\www\Castelnovo Gianluca\SITO PANDA\fonte2.ttf');
    font-family: 'fonte2';
    src: url('fonte2fieldset.eot');
    src: local('fonte2'),
         local('fonte2'),
         url('fonte2.ttf') format('truetype'),
         url('fonte2.svg#font') format('svg');
}
 body {
       background-image: url("8.jpg");
 }
input{
  font-family: 'fonte2';
   font-size: 15px;
   color: black;
}
table{
  font-family: 'fonte2';
   font-size: 30px;
   color: black;

   }
b{
  font-family: 'fonte2';
  font-size: 45px;
 color: black;
   margin-top: 250px;
   margin-left: 100px;

}

 .error-message {
 	padding: 7px 10px;
 	background: #fff1f2;
 	border: #ffd5da 1px solid;
 	color: #d6001c;
 	border-radius: 4px;
 }
 .success-message {
 	padding: 7px 10px;
 	background: #cae0c4;
 	border: #c3d0b5 1px solid;
 	color: #027506;
 	border-radius: 4px;
 }
 .demo-table {
 	background-image: url("rawr.jpg");
 	width: 100%;
 	border-spacing: initial;
 	margin: 2px 0px;
 	word-break: break-word;
 	table-layout: auto;
 	line-height: 1.8em;
 	color: black;
 	border-radius: 20px;
  margin-top: 50px;
 	padding: 10px 20px;
 }
 .demo-table td {
 	padding: 15px 0px;
 }
 .demoInputBox {
 	padding: 5px 15px;
 	border: #a9a9a9 2px solid;
 	border-radius: 4px;
  margin-right: 700px;
 }
 .btnRegister {
   font-family: 'fonte2';
   font-size: 40px;
 	padding: 10px 30px;
  background: transparent;
  border: none !important;
 	color: black;
 	cursor: pointer;
 	border-radius: 10px;
 	margin-left: 600px;
  margin-top: 5px;
 }

 ul {
     list-style-type: none;
     margin: 0;
     padding: 0;
     overflow: hidden;
     background-color: #ffffff;
 }

 li {
     float: left;
 }

 li a {
     display: block;
     color: black;
     text-align: center;
     padding: 14px 16px;
     text-decoration: none;
 }

 li a:hover:not(.active) {
     background-color: #3779c3;
 }

 .active {
     background-color: #2078db;
 }

 </style>



</BODY>
</HTML>
