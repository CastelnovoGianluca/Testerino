<?php

function connetti() {
    error_reporting(E_ALL);
    ini_set('display_errors', 'on');
    $servername = 'localhost';
    $port = 3306;
    $username = 'root';
    $password = 'mysql';
    $dbName= 'DB_POKEMON';
  try
  {
    $conn = new PDO("mysql:host=$servername;dbname=$dbName", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $conn;
  }
  catch(PDOException $e)
  {
    echo "Connection failed: " . $e->getMessage();
  }
}

function register($conn,$user,$Name,$LastName, $pwd, $Email)
{
     try{
          $query = "INSERT INTO Register (Username,Nome,Cognome,Password,Email) VALUES (:userName,:firstName,:lastName,:password,:userEmail)";
          $sql = $conn->prepare($query);
          $sql->execute(array(':userName'=>$user, ':password'=>$pwd, ':firstName'=>$Name, ':lastName'=>$LastName, ':userEmail'=>$Email));
          return true;
     }
     catch(PDOException $e){
            echo 'Error: '.$e->getMessage();
            return false;
     }
}

function login($conn, $mail,$pass){

  try{
       $query = "SELECT * FROM Register WHERE Email=:email AND Password=:pass";
       $sql = $conn->prepare($query);
       $sql->execute(array(':email'=>$mail, ':pass'=>$pass));
       $result = $sql->fetch(PDO::FETCH_ASSOC);
       if (null != $result["Email"].$result["Password"]) return true;
       else return false;

  }
  catch(PDOException $e){
         echo 'Error: '.$e->getMessage();
         return false;
  }

}

 ?>
