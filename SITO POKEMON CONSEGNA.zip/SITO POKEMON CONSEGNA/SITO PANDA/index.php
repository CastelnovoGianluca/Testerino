<HTML>

<HEAD>
  <body>
  <ul>
    <li><a class="active" href="index.php">Home</a></li>
  <adestra>  <li><a href="register.php" >Register</a></li> </adestra>
    <adestra> <li><a href="login.php">Login</a></li> </adestra>
    <li><a href="listapokemon.php">Ricerca</a></li>
    <li><a href="ricercapoke.php">Catalogo</a></li>
  </ul>
  </ul>
</body>
<h2> WELCOME </h2>
</HEAD>
<BODY>

  <style>
  adestra {
    float:right ;
  }
  @font-face {
    font-family: 'fonte2';
    src: url('C:\Program Files (x86)\Ampps\www\Castelnovo Gianluca\SITO PANDA\fonte2.ttf');
    font-family: 'fonte2';
    src: url('fonte2fieldset.eot');
    src: local('fonte2'),
         local('fonte2'),
         url('fonte2.ttf') format('truetype'),
         url('fonte2.svg#font') format('svg');
  }
 body {
       background-image: url("44.jpg");
 }

div1{
   margin-top: 20px;
   text-decoration:none;
}
 div{
 margin-top: 100px;
 text-decoration:none;
 }
h2{
  font-family: 'fonte2';
  font-size: 60px;
  margin-left: 300px;
 margin-top: 40px;
  color: black;
  text-decoration:none;

}

ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #ffffff;
}

li {
    float: left;
}

li a {
    display: block;
    color: black;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover:not(.active) {
    background-color: #ff4f28;
}

.active {
    background-color: #ff2e00;
}

 </style>


</BODY>
</HTML>
