<HTML>

<HEAD>
</HEAD>
<BODY>
  <ul>
    <li><a class="active" href="index.php">Home</a></li>
  <adestra>  <li><a href="register.php" >Register</a></li> </adestra>
    <adestra> <li><a href="login.php">Login</a></li> </adestra>
    <li><a href="listapokemon.php">Ricerca</a></li>
    <li><a href="ricercapoke.php">Catalogo</a></li>
  </ul>
</ul>


  <tr>
        <div><b>LOGIN</b></div>
        </tr>
  <form name="frmRegistration" method="post" action="login1.php">
  	<table border="0" width="500" align="center" class="demo-table">
  		<?php if(!empty($success_message)) { ?>
  		<div class="success-message"><?php if(isset($success_message)) echo $success_message; ?></div>
  		<?php } ?>
  		<?php if(!empty($error_message)) { ?>
  		<div class="error-message"><?php if(isset($error_message)) echo $error_message; ?></div>
  		<?php } ?>
      <tr>
        <td>EMAIL</td>
        <td><input type="text" class="demoInputBox" name="userEmail"></td>
      </tr>
  		<tr>
  			<td>PASSWORD</td>
  			<td><input type="password" class="demoInputBox" name="password" value=""></td>
  		</tr>
  		<tr>
  			<td colspan=2>
    			<input type="submit" name="login-user" value="LOGIN" class="btnLogin"></td>
  		</tr>
  	</table>
  </form>

  <style>

  adestra {
    float:right ;
  }

  @font-face {
    font-family: 'fonte2';
    src: url('C:\Program Files (x86)\Ampps\www\Castelnovo Gianluca\SITO PANDA\fonte2.ttf');
    font-family: 'fonte2';
    src: url('fonte2fieldset.eot');
    src: local('fonte2'),
         local('fonte2'),
         url('fonte2.ttf') format('truetype'),
         url('fonte2.svg#font') format('svg');
}
 body {
       background-image: url("78.jpg");
 }
 ul {
     list-style-type: none;
     margin: 0;
     padding: 0;
     overflow: hidden;
     background-color: #ffffff;
 }

 li {
     float: left;
 }

 li a {
     display: block;
     color: black;
     text-align: center;
     padding: 14px 16px;
     text-decoration: none;
 }

 li a:hover:not(.active) {
     background-color: #e51e1e;
 }

 .active {
     background-color: #d00b0b;
 }
input{
  font-family: 'fonte2';
   font-size: 30px;
   color: black;
}
table{
  font-family: 'fonte2';
   font-size: 30px;
   color: black;

   }
b{
  font-family: 'fonte2';
  font-size: 45px;
 color: black;

}
div{
  margin-top: 200px;
  margin-left: 550px
}
 .error-message {
 	padding: 7px 10px;
 	background: #fff1f2;
 	border: #ffd5da 1px solid;
 	color: #d6001c;
 	border-radius: 4px;
 }
 .success-message {
 	padding: 7px 10px;
 	background: #cae0c4;
 	border: #c3d0b5 1px solid;
 	color: #027506;
 	border-radius: 4px;
 }
 .demo-table {
 	background-image: url("rawr.jpg");
 	width: 100%;
 	border-spacing: initial;
 	margin: 2px 0px;
 	word-break: break-word;
 	table-layout: auto;
 	line-height: 1.8em;
 	color: black;
 	border-radius: 20px;
  margin-top: 30px;
  margin-left: 400PX;
 	padding: 20px 40px;
 }
 .demo-table td {
 	padding: 15px 0px;
 }
 .demoInputBox {
 	padding: 5px 20px;
 	border: #a9a9a9 2px solid;
 	border-radius: 4px;
  margin-right: 700px;
 }
 .btnLogin {
   font-family: 'fonte2';
   font-size: 40px;
 	padding: 10px 30px;
  background: transparent;
  border: none !important;
 	color: black;
 	cursor: pointer;
 	border-radius: 10px;
 	margin-left: 800px;
  margin-top: 5px;
 }


 </style>


</BODY>
</HTML>
